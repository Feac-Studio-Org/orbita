#!/bin/sh
# Instala Órbita para el usuario actual: copia la app a ~/.local/share/orbita y crea el acceso en el menú.
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
DEST="$HOME/.local/share/orbita"
mkdir -p "$DEST" "$HOME/.local/share/applications" "$HOME/.local/bin"
cp -r "$DIR/orbita" "$DIR/lib" "$DIR/data" "$DEST/"
ln -sf "$DEST/orbita" "$HOME/.local/bin/orbita"
cat > "$HOME/.local/share/applications/orbita.desktop" <<DESK
[Desktop Entry]
Name=Órbita
Comment=Tu vida, tu trabajo y tus equipos
Exec=$DEST/orbita
Icon=$DEST/data/orbita.png
Terminal=false
Type=Application
Categories=Office;ProjectManagement;
StartupWMClass=com.feacestudio.orbita
DESK
echo "Órbita quedó instalada. Búscala en el menú de aplicaciones."
